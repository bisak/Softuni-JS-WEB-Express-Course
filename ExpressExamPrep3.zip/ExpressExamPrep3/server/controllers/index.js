const home = require('./home-controller')
const users = require('./users-controller')
const posts = require('./post-controller')

module.exports = {
  home: home,
  users: users,
  posts: posts
}
